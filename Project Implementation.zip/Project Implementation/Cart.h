#pragma once
#include "Catalogue.h"
#include "Inventory.h"
#include "Product.h"
#include "CheckOut.h"
#include "Store.h"
#include <iostream>
using namespace std;
char Cartname[100] = "Hoalla.bin";


class Cart :public CheckOut
{
public:
	Cart()
	{

	}
	void setCartName(char* name)
	{
		if (strcmp(Cartname, name) != 0)
		{
			strcat_s(name, 100, "Cart");
			strcat_s(name, 100, ".bin");
			strcpy_s(Cartname, 100, name);
			cout << name << endl
			<< Cartname << endl;
		}

	}
	void InsertCart(char* City, int temp_serial)
	{

		int temp_q, before_q;
		Inventory temp_i;
		temp_i.setInventoryName(City);
		Product temp = getObject(Inventoryname, temp_serial);
		before_q = temp.get_quantity();
		do {
			cout << "Enter the quantity of product";
			cin >> temp_q;
			if (!(before_q >= temp_q))
			{
				cout << "The quantity in Inventory is less than the quantity needed" << endl;
				
			}
		} while (!(before_q >= temp_q));
				temp.set_quantity(temp_q);
				insert_Product(Cartname, temp);
				cout << "------------------------CART-----------------------" << endl
					<< "                 The present Cart!!!";
				Display_Products(Cartname);
				temp_i.ViewInventory(Inventoryname);
		
	}
	void UpdatCart()
	{
		system("cls");
		Display_Products(Cartname);
		int temp_serial, temp_quantity, before_q;
		do {
			cout << "Enter serial number of the product you  want to update in the Cart" << endl;
			cin >> temp_serial;
		} while (!SearchSerial(Cartname, temp_serial));
		Product temp;
		temp = getObject(Cartname, temp_serial);
		temp.Display();
		
		before_q = temp.get_quantity();
		cout << before_q << endl;//remove later
		do {
			cout << "Enter the quantity of product";
			cin >> temp_quantity;
			if (!(before_q >= temp_quantity))
			{
				cout << "The quantity in Caralogue is less than the quantity needed" << endl;
				
			}
		} while (!(before_q >= temp_quantity));
		temp.set_quantity(temp_quantity);
			Update(Cartname, temp);
			//break;
		
		Display_Products(Cartname);//remove later
	}
	void DeleteCart()
	{
		int temp_serial;
		do {
			cout << "Enter serial Number";
			cin >> temp_serial;
		} while (!SearchSerial(Cartname, temp_serial));
		if (SearchSerial(Cartname, temp_serial))
		{
			deleteObject(Cartname, temp_serial);
		}
		Display_Products(Cartname);//remove later
	}


	void ViewCart()
	{

		//setCartName(name);
		if (checkCartExist())
		{
			Display_Products(Cartname);
		}
		else
			cout << "Cart for respective customer doesnot exist" << endl;
	}
		bool checkCartExist()
		{
			bool check = false;
			Inventory temp;
			ifstream myFile(Cartname, ios::binary);
			while (myFile.read((char*)&temp, sizeof(temp)))
			{
				//temp.Display();
				//cout << endl;
				check = true;
			}
			myFile.close();
			return check;
		}
		void Payment(char* City_check, char** Cities)
		{

			Store temp_s;
			Inventory temp_i;
			int TotalBill = 0;
			cout << "----------------------------------  CART  ---------------------------------------" << endl
				<< "                      Present Cart !!!!     " << endl;
			ViewCart();
			int opt_1;
			cout << "(1)_COD" << endl
				<< "(2)_Debit Card" << endl
				<< " (3)_Easy Paisa" << endl;
			cin >> opt_1;
			Product temp;
			ifstream myFile(Cartname, ios::binary);
			while (myFile.read((char*)&temp, sizeof(temp)))
			{ //for COD
				
					switch (opt_1)
					{
					case 1:

					{

						strcpy_s(storefilename, 100, City_check);
						strcat_s(storefilename, 100, ".bin");
						if (temp_s.checkCity(storefilename, City_check))
						{
							if (temp_i.SearchInventory(City_check, temp.get_serial_number()))
							{
								temp_i.setInventoryName(City_check);
								Product InInventory;
								InInventory = getObject(Inventoryname, temp.get_serial_number());
								InInventory.set_quantity(InInventory.get_quantity() - temp.get_quantity());
								Update(Inventoryname, InInventory);
								//temp_i.ViewInventory(City_check);
								TotalBill = TotalBill + (temp.get_quantity() * temp.getPrice()) + COD(true);
							}

							else
							{
								int i = 0;
								while (i < 100)
								{
									if (strcmp(Cities[i], "\0") != 0)
									{
										if (temp.getCategory() != "Perishable")
										{
											strcpy_s(storefilename, 100, Cities[i]);
											strcat_s(storefilename, 100, ".bin");
											if (temp_s.checkCity(storefilename, Cities[i]))
											{
												if (temp_i.SearchInventory(Cities[i], temp.get_serial_number()))
												{
													temp_i.setInventoryName(Cities[i]);
													temp_i.ViewInventory(Inventoryname);
													Product InInventory;
													InInventory = getObject(Inventoryname, temp.get_serial_number());
													InInventory.Display();//delete later
													InInventory.set_quantity(InInventory.get_quantity() - temp.get_quantity());
													Update(Inventoryname, InInventory);
													temp_i.ViewInventory(Cities[i]);
													TotalBill = TotalBill + (temp.get_quantity() * temp.getPrice()) + COD(false);
													break;
												}
											}
										}
										else
											cout << "Product is Perishable and the Store is not in Ur City" << endl;
								}
									i++;
								}
							}
						}
					}
					break;
					case 2:

					{
						CreditCard();
						strcpy_s(storefilename, 100, City_check);
						strcat_s(storefilename, 100, ".bin");
						if (temp_s.checkCity(storefilename, City_check))
						{
							if (temp_i.SearchInventory(City_check, temp.get_serial_number()))
							{
								temp_i.setInventoryName(City_check);
								Product InInventory;
								InInventory = getObject(Inventoryname, temp.get_serial_number());
								InInventory.set_quantity(InInventory.get_quantity() - temp.get_quantity());
								Update(Inventoryname, InInventory);
								temp_i.ViewInventory(City_check);
								TotalBill = TotalBill + (temp.get_quantity() * temp.getPrice()); 
							}

							else
							{
								int i = 0;
								while (i < 100)
								{
									if (strcmp(Cities[i], "\0") != 0)
									{
										if (temp.getCategory() != "Perishable")
										{
											strcpy_s(storefilename, 100, Cities[i]);
											strcat_s(storefilename, 100, ".bin");
											if (temp_s.checkCity(storefilename, Cities[i]))
											{
												if (temp_i.SearchInventory(Cities[i], temp.get_serial_number()))
												{
													temp_i.setInventoryName(Cities[i]);
													Product InInventory;
													InInventory = getObject(Inventoryname, temp.get_serial_number());
													InInventory.set_quantity(InInventory.get_quantity() - temp.get_quantity());
													Update(Inventoryname, InInventory);
													temp_i.ViewInventory(Cities[i]);
													TotalBill = TotalBill + (temp.get_quantity() * temp.getPrice());
													break;
												}
											}
										}
										else
											cout << "Product is Perishable and the Store is not in Ur City" << endl;
									}
									i++;
								}
							}
						}
					}
						
						break;
					case 3:
					{
						EasyPaisa();
						strcpy_s(storefilename, 100, City_check);
						strcat_s(storefilename, 100, ".bin");
						if (temp_s.checkCity(storefilename, City_check))
						{
							if (temp_i.SearchInventory(City_check, temp.get_serial_number()))
							{
								temp_i.setInventoryName(City_check);
								Product InInventory;
								InInventory = getObject(Inventoryname, temp.get_serial_number());
								InInventory.set_quantity(InInventory.get_quantity() - temp.get_quantity());
								Update(Inventoryname, InInventory);
								temp_i.ViewInventory(City_check);
								TotalBill = TotalBill + (temp.get_quantity() * temp.getPrice());
							}

							else
							{
								int i = 0;
								while (i < 100)
								{
									if (strcmp(Cities[i], "\0") != 0)
									{
										if (temp.getCategory() != "Perishable")
										{
											strcpy_s(storefilename, 100, Cities[i]);
											strcat_s(storefilename, 100, ".bin");
											if (temp_s.checkCity(storefilename, Cities[i]))
											{
												if (temp_i.SearchInventory(Cities[i], temp.get_serial_number()))
												{
													temp_i.setInventoryName(Cities[i]);
													Product InInventory;
													InInventory = getObject(Inventoryname, temp.get_serial_number());
													InInventory.set_quantity(InInventory.get_quantity() - temp.get_quantity());
													Update(Inventoryname, InInventory);
													temp_i.ViewInventory(Cities[i]);
													TotalBill = TotalBill + (temp.get_quantity() * temp.getPrice());
													break;
												}
											}
										}
										else
											cout << "Product is Perishable and the Store is not in Ur City" << endl;
									}
									i++;
								}
							}
						}
					}
					
							break;
					}
				
					//cout << "Total Bill: " << TotalBill << endl;
				myFile.close();
			}
			cout << "Total Bill: " << TotalBill << endl;
		}
		//cout << "Total Bill: " << TotalBill << endl;
		
};