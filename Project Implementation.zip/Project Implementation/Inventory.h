#pragma once
//for display donot match the city of manager and the shop
//take input of the city he wants inventory of to be displayed 
#include <iostream>
#include <string.h>
#include "Product.h"
char Inventoryname[100] = "Hoalla.bin";

//#include "Store.h"
//const char* fileforinventory = "Inventory.bin";//will be stored in store file
//static int setsize = 0;//checks if the object iserted exeeds the size set for
//the product
class Inventory
{
private:
	//char City[100];
public:
	Inventory(){}
	/*void setCity(string City)
	{
		strcpy_s(this->City, 100, City.c_str());
	}*/
	void setInventoryName(char* name)
	{
		if (strcmp(Inventoryname, name) != 0)
		{
			strcat_s(name, 100, "Inventory");
			strcat_s(name, 100, ".bin");
			strcpy_s(Inventoryname, 100, name);
		//	cout << name << endl
				//<< Inventoryname << endl;
		}

	}
	void InsertInInventory()
	{
		
		cout << "------------------------INVENTORY-----------------------" << endl
			<< "                 The present inventory!!!";
		Display_Products(Inventoryname);
		int temp_serial;
		cout << " --------------------- CATALOGUE -------------------------------" << endl
			<< "         Choose the items you want to add into the inventory";
		Display_Products(fileforcatalogue);
		do {
			cout << "Enter the serial number of the product you want to add into the inventory" << endl;
			cin >> temp_serial;
		} while (!SearchSerial(fileforcatalogue, temp_serial));
		Product temp = getObject(fileforcatalogue, temp_serial);
		insert_Product(Inventoryname, temp);
	}
	void UpdateProductOfInventory()
	{
		int temp_serial, temp_price, temp_quantity, opt_1;
		do {
			cout << "Enter serial number of the product you  want to update in the inventory" << endl;
			cin >> temp_serial;
		} while (!SearchSerial(Inventoryname, temp_serial));
		Product temp;
		temp = getObject(Inventoryname, temp_serial);
		temp.Display();
		cout << "If want to update price press 1" << endl
			<< "If want to update quantity press 2" << endl
			<< "If want to update both press 3" << endl;
		cin >> opt_1;
		switch (opt_1)
		{
		case 1:
			cout << "Enter New Price: ";
			cin >> temp_price;
			temp.set_price(temp_price);
			Update(Inventoryname, temp);
			break;
		case 2:
			cout << "Enter New Quantity for the product";
			cin >> temp_quantity;
			temp.set_quantity(temp_quantity);
			Update(Inventoryname, temp);
			break;
		case 3:
			cout << "Enter New Price: ";
			cin >> temp_price;
			temp.set_price(temp_price);
			//Update(fileforcatalogue, temp);
			cout << "Enter New Quantity for the product";
			cin >> temp_quantity;
			temp.set_quantity(temp_quantity);
			Update(Inventoryname, temp);
			break;
		}
		//Display_Products(Inventoryname);
	}
	void AddINInventory()
	{
		bool check = false;
		Product temp;
		temp.Create_Product();
		int i = 0;
		while (!SearchSerial(fileforcatalogue,i))
		{
			if (getObject(fileforcatalogue, i) == temp)
			{
				check = true;
				insert_Product(Inventoryname, temp);
				break;
			}
			i++;
		}
		if (check == false)
		{
			cout << "Product does not exist in the catalogue" << endl
				<< "Contact the Admin" << endl;
		}
		//Display_Products(Inventoryname);
	}
	void Delete()
	{
		int temp_serial;
		do {
			cout << "Enter serial Number";
			cin >> temp_serial;
		} while (!SearchSerial(Inventoryname, temp_serial));
		if (SearchSerial(Inventoryname, temp_serial))
		{
			deleteObject(Inventoryname, temp_serial);
		}
		//Display_Products(Inventoryname);
	}

	void ViewInventory(char* name)
	{
		setInventoryName(name);
		if (checkInventoryExist())
		{
			Display_Products(Inventoryname);
		}
		else
			cout << "Inventory for respective City doesnot exist" << endl;
}
	bool checkInventoryExist()
	{
		bool check = false;
		Inventory temp;
		ifstream myFile(Inventoryname, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			//temp.Display();
			//cout << endl;
			check = true;
		}
		myFile.close();
		return check;
	}
	bool SearchInventory(char* name,int temp_serial)
	{
		bool check;
		setInventoryName(name);
		if (SearchSerial(Inventoryname, temp_serial))
		{
			check = true;
		}
		else
			check = false;
		return check;
	}
};