#pragma once
/*it is automatically create
if the admin wants to add a product create a product object,call createObject function and write that object 
if he wants to edit a Product, can edit only price and quantity
for this create an object of product get object make it equal to it set price and quantity
then call update
if wants to delete give the serial number only and it deletes that*/
#include <iostream>
#include <string.h>
#include "../ThirdSemesterProjectOOP/Product.h"
using namespace std;
const char* fileforcatalogue = "Catalogue.bin";
class Catalogue 
{
private:
	Product* Perishable=new Product[17];
	Product* Non_Perishable=new Product[13];
	Product* Hygiene=new Product [9];
	Product* Household_Cleaning=new Product[6];
public:
	Catalogue()
	{}
	void CreateCatalogue() {    //////////  perishable////////////
		Perishable[0].set_Entities("Perishable","Chicken", 200, "kg", 10);
		Perishable[1].set_Entities("Perishable", "Beef", 300, "kg", 10);
		Perishable[2].set_Entities("Perishable", "Mutton", 400, "kg", 10);
		Perishable[3].set_Entities("Perishable", "Fish", 100, "kg", 10);
		Perishable[4].set_Entities("Perishable", "Milk", 200, "liters", 10);
		Perishable[5].set_Entities("Perishable", "Eggs", 200, "dozens", 10);
		Perishable[6].set_Entities("Perishable", "Yougurt", 200, "cup", 10);
		Perishable[7].set_Entities("Perishable", "Cheese", 200, "g", 10);
		Perishable[8].set_Entities("Perishable", "Apple", 200, "lb", 10);
		Perishable[9].set_Entities("Perishable", "Banana", 200, "lb", 10);
		Perishable[10].set_Entities("Perishable", "Mango", 200, "lb", 10);
		Perishable[11].set_Entities("Perishable", "Orange", 200, "lb", 10);
		Perishable[12].set_Entities("Perishable", "Watermelon", 200, "lb", 10);
		Perishable[13].set_Entities("Perishable", "Tomato", 200, "lb", 10);
		Perishable[14].set_Entities("Perishable", "Onion", 200, "lb", 10);
		Perishable[15].set_Entities("Perishable", "Cucumber", 200, "lb", 10);
		Perishable[16].set_Entities("Perishable", "Potatoes", 200, "lb", 10);
		/////Inser perishable goods
		for (int i = 0; i <= 16; i++)
		{
			insert_Product(fileforcatalogue, Perishable[i]);
		}
		//////   non-perishable//////////
		Non_Perishable[0].set_Entities("Non_Perishable", "Chocolate", 24, "pieces", 10);//quantity is number of boxes
		Non_Perishable[1].set_Entities("Non_Perishable", "Chips", 24, "pieces", 10);
		Non_Perishable[2].set_Entities("Non_Perishable", "Biscuits", 24, "pieces", 10);
		Non_Perishable[3].set_Entities("Non_Perishable", "Cinnamon", 24, "g", 10);
		Non_Perishable[4].set_Entities("Non_Perishable", "Cloves", 24, "g", 10);
		Non_Perishable[5].set_Entities("Non_Perishable", "Cloriander", 24, "g", 10);
		Non_Perishable[6].set_Entities("Non_Perishable", "Lentils", 24, "g", 10);
		Non_Perishable[7].set_Entities("Non_Perishable", "Wheat", 24, "g", 10);
		Non_Perishable[8].set_Entities("Non_Perishable", "Flour", 24, "g", 10);
		Non_Perishable[9].set_Entities("Non_Perishable", "Rice", 24, "g", 10);
		Non_Perishable[10].set_Entities("Non_Perishable", "Corn Flakes", 24, "g", 10);//Cerals
		Non_Perishable[11].set_Entities("Non_Perishable", "Koko Kruch", 24, "g", 10);
		Non_Perishable[12].set_Entities("Non_Perishable", "Milo", 24, "g", 10);
		//Inser non_perishable
		for (int i = 0; i <= 12; i++)
		{
			insert_Product(fileforcatalogue, Non_Perishable[i]);
		}
		//////////// personal hygiene///////////////////
		Hygiene[0].set_Entities("Hygiene", "Loreal", 1200, "ltrs", 12);//shmapoo
		Hygiene[1].set_Entities("Hygiene", "Lifebouy", 1200, "ltrs", 12);
		Hygiene[2].set_Entities("Hygiene", "Sunsilk", 1200, "ltrs", 12);
		Hygiene[3].set_Entities("Hygiene", "Detol", 1200, "packs", 12);
		Hygiene[4].set_Entities("Hygiene", "Dove", 1200, "packs", 12);
		Hygiene[5].set_Entities("Hygiene", "Detol", 1200, "packs", 12);
		Hygiene[6].set_Entities("Hygiene", "Detol", 1200, "ltrs", 12);
		Hygiene[7].set_Entities("Hygiene", "LifeBouy", 1200, "ltrs", 12);
		Hygiene[8].set_Entities("Hygiene", "Safeguard", 1200, "ltrs", 12);
		//insert Hygiene
		for (int i = 0; i <= 8; i++)
		{
			insert_Product(fileforcatalogue, Hygiene[i]);
		}
		Household_Cleaning[0].set_Entities("Household_Cleaning", "Surf Exel", 1200, "ltrs", 12);
		Household_Cleaning[1].set_Entities("Household_Cleaning", "Tide", 1200, "ltrs", 12);
		Household_Cleaning[2].set_Entities("Household_Cleaning", "Vim", 1200, "ltrs", 12);
		Household_Cleaning[3].set_Entities("Household_Cleaning", "Max", 1200, "ltrs", 12);
		Household_Cleaning[4].set_Entities("Household_Cleaning", "Harpic", 1200, "ltrs", 12);
		Household_Cleaning[5].set_Entities("Household_Cleaning", "Domex", 1200, "ltrs", 12);
		//insert Household_Cleaning
		for (int i = 0; i <=5; i++)
		{
			insert_Product(fileforcatalogue, Household_Cleaning[i]);
		}
		//Display_Products(fileforcatalogue);
	}
	bool checkifcatalogue()
	{
		bool check = false;
		Catalogue temp;
		ifstream myFile(fileforcatalogue, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			//temp.Display();
			//cout << endl;
			check = true;
		}
		myFile.close();
		return check;
	}
	void Add_Product()
	{
		Product temp;
		temp.Create_Product();
		insert_Product(fileforcatalogue, temp);
		//Display_Products(fileforcatalogue);
	}
	void DeleteProductinCatalogue()
	{
		int temp_serial;
		do {
			cout << "Enter serial Number";
			cin >> temp_serial;
		} while (!SearchSerial(fileforcatalogue, temp_serial));
		if (SearchSerial(fileforcatalogue, temp_serial))
		{
			deleteObject(fileforcatalogue, temp_serial);
		}
		//Display_Products(fileforcatalogue);
	}
	void EditProduct()
	{
		int temp_serial, temp_price, temp_quantity, opt_1;
		//char con;
		do {
			cout << "Enter the serial number of the product you want to edit";
			cin >> temp_serial;
		} while (!SearchSerial(fileforcatalogue, temp_serial));
		Product temp;
		temp = getObject(fileforcatalogue, temp_serial);
		temp.Display();
		cout << "If want to update price press 1" << endl
			<< "If want to update quantity press 2" << endl
			<< "If want to update both press 3" << endl;
		cin >> opt_1;
		switch (opt_1)
		{
		case 1:
			cout << "Enter New Price: ";
			cin >> temp_price;
			temp.set_price(temp_price);
			Update(fileforcatalogue, temp);
			break;
		case 2:
			cout << "Enter New Quantity for the product";
			cin >> temp_quantity;
			temp.set_quantity(temp_quantity);
			Update(fileforcatalogue, temp);
			break;
		case 3:
			cout << "Enter New Price: ";
			cin >> temp_price;
			temp.set_price(temp_price);
			//Update(fileforcatalogue, temp);
			cout << "Enter New Quantity for the product";
			cin >> temp_quantity;
			temp.set_quantity(temp_quantity);
			Update(fileforcatalogue, temp);
			break;
		}
		//Display_Products(fileforcatalogue);
	}
	Product GetProductFromCatalogue(int Temp_serial)
	{
		return getObject(fileforcatalogue, Temp_serial);
	}
	void DisplayCatalogue()
	{
		Display_Products(fileforcatalogue);
	}
};