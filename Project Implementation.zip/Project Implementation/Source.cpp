#include <iostream>
#include "ShoppingMart.h"
using namespace std;
int main()
{
	Registration r;
	r.start();
	return 0;
}