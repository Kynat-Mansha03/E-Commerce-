#pragma once
#include <iostream>
using namespace std;
class Person {
protected:
	char CNIC[14];
	char Pass[100];
	char user_name[100];
	char gender[50];
	char phone_number[100];
	char personal_City[50];
	
	Person()  {}
	Person(string CNIC, string Pass, string user_name, string gender, string phone_number, string personal_City)
	{
		strcpy_s(this->CNIC,13, CNIC.c_str());
		strcpy_s(this->Pass ,100, Pass.c_str());
		strcpy_s(this->user_name,100, user_name.c_str());
		strcpy_s(this->gender,50 , gender.c_str());
		strcpy_s(this->phone_number, 100, phone_number.c_str());
		strcpy_s(this->personal_City ,50, personal_City.c_str());
	} 
	bool Verify_Password(string Pass) {
		bool special_char = false, small_char= false, caps_char = false, num_char = false;
		if (Pass.length() >= 8)
		{
			for (int i = 0; i < Pass.length(); i++)
			{
				if (!((Pass[i] >= '0' && Pass[i] <= '9') ||
					(Pass[i] >= 'A' && Pass[i] <= 'Z') ||
					(Pass[i] >= 'a' && Pass[i] <= 'z')))
				{
					special_char = true;
				}
				else if (Pass[i] >= '0' && Pass[i] <= '9')
				{
					num_char = true;
				}
				else if (Pass[i] >= 'A' && Pass[i] <= 'Z')
				{
					caps_char = true;
				}
				else if (Pass[i] >= 'a' && Pass[i] <= 'z')
				{
					small_char = true;
				}
			}

			if (special_char && num_char && caps_char && small_char)
			{
				return true;

			}
			else
			{
				cout << "Does not meet requirements" << endl;
				return false;
			}
		}
		else
		{
			cout << "Does not meet requirements" << endl;
			return false;
		}
	}
	bool Verify_CNIC(string CNIC) {
		bool check;
		if (CNIC.length() == 13)
		{
			for (int i = 0; i < 13; i++)
			{
				if (!(CNIC[i] >= '0' && CNIC[i] <= '9'))
				{
					cout << "Does not meet requirements" << endl;
					check= false;
				}
			}

			check= true;
		}
		else
		{
			cout << "Does not meet requirements" << endl;
			check= false;
		}
		return check;
	}

public:
	
	const char* getName() /*const*/ { return user_name; }
	const char* getCNIC() /*const*/ { return CNIC; }
	const char* getPass() /*const*/ { return Pass; }
	const char* getPhone_Number() /*const*/ { return phone_number; }
	//virtual void NoNeed() = 0;
};