#pragma once
#include <iostream>
#include <string.h>
#include <fstream>
#include "Cart.h"
#include "Catalogue.h"
#include "Product.h"
#include "Store.h"
#include "Feedback.h"
//#include "../ThirdSemesterProjectOOP/VectorC.h"
#include "../ThirdSemesterProjectOOP/Person.h"
using namespace std;
/*for customer, we purchase a product, enter the quantity user purchases, substract that from
* the original quantity of the product and update that copy the product into a seperate cart file and update the quantity
* in that cart file to the quantity u purchased, this way a cart will be made, at this point make product
* reading and writting global in product file
* always update and then display again
* */
const char* filename = "Customer.bin";

class Customer :public Person
{
	Cart cart;
	//checkStimulation*checksti;
public:
	Customer()
	{}
	void CreateCart(char** Cities)
	{
		int opt_1;
		//Inventory temp_i;
		Feedback temp_f;
		int temp_serial;
		Catalogue c;
		char con;
		cart.setCartName(user_name);
		//c.DisplayCatalogue();
		do
		{
			//system("cls");
			cout << "(1)_Want to Insert In Cart" << endl
				<< "(2)_Want to Update Product in Cart" << endl //can update quantity only 
				<< "(3)_Want to Delete Prodcut from the Cart" << endl
				<< "(4)_Display Cart" << endl
				<< "(5)_Get Bill" << endl
				<< "(6)_Enter FeedBack" << endl;
			cin >> opt_1;
			switch (opt_1) {
			case 1:
				cout << "----------------- MAIN MENU:----------------------------" << endl
					<< "Select the items you want to buy on the basis of their respective serial numbers" << endl;

				c.DisplayCatalogue();
				cout << "------------------------------ REVIEWS --------------------------" << endl;
				temp_f.Display_FeedBacks();
				cout << "Enter Serial Number of the Product You Want to Add In Cart: " << endl;
				cin >> temp_serial;
				if (SearchSerial(fileforcatalogue, temp_serial))
				{
					if (ProductPresent(temp_serial, Cities))
					{

					}
					else
					{
						cout << "Out of Stock" << endl;
					}
				}
				else
				{
					cout << "Not in Stock" << endl;
				}
				break;
			case 2:
				cart.UpdatCart();
				break;
			case 3:
				cart.DeleteCart();
				break;
			case 4:
				cart.ViewCart();
				break;
			case 5:
				cart.Payment(personal_City,Cities);
			case 6:
				temp_f.Enter_FeedBack();
			}
			cout << "If want to Continue, press Y/y" << endl;
			cin >> con;
		}while(con =='Y'||con =='y');
	}
	bool ProductPresent(int temp_serial, char** Cities)
	{
		bool check = false;
		Store temp;
		Inventory temp_i;

		strcpy_s(storefilename, 100, this->personal_City);
		strcat_s(storefilename, 100, ".bin");
		if (temp.checkCity(storefilename, personal_City))
		{
			if (temp_i.SearchInventory(personal_City, temp_serial))
			{
				check = true;
				cart.InsertCart(personal_City, temp_serial);
			}

			else
			{
				int i = 0;
				while (i < 100)
				{
					if (strcmp(Cities[i], "\0") != 0)
					{
						strcpy_s(storefilename, 100, Cities[i]);
						strcat_s(storefilename, 100, ".bin");
						if (temp.checkCity(storefilename, Cities[i]))
						{
							if (temp_i.SearchInventory(Cities[i], temp_serial))
							{
								check = true;
								cart.InsertCart(Cities[i], temp_serial);
								break;
							}
						}
					}
					i++;
				}
			}
		}
		return check;
	}
	void DeleteCustomers(char* temp_username)
	{
		Customer temp;
		fstream myFile(filename, ios::in | ios::out | ios::binary);
		ofstream myFile_temp("temp.bin", ios::app | ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp))) {
			if ((strcmp(temp.user_name,temp_username)!=0)) {
				myFile_temp.write((char*)&temp, sizeof(temp));
			}
		}
		myFile.close();
		myFile_temp.close();
		remove(filename);
		rename("temp.bin", filename);
	}
	void EnterCustomer()
	{
		system("CLS");
		do
		{
			cout << "Enter username";
			cin >> user_name;
		} while (readAllusername(user_name));
		do
		{
			do {
				cout << "Enter CNIC";
				cin >> CNIC;
			} while (!Verify_CNIC(CNIC));
		} while (readAllCNIC(CNIC));
	
		cout << "Enter Gender";
		cin >> gender;
		do
		{
			cout << "Enter password: ";
			cin >> Pass;
		} while (!Verify_Password(Pass));
		cout << "Enter Phone Number";
		cin >> phone_number;
		cout << "Enter Personal City";
		cin >> personal_City;
		cout << "Customer Created" << endl;
		Customer_insert(*this);
		//readCustomer();
	}
	bool Verify(const char* temp_username, const char* temp_password)
	{
		bool check = false;
		Customer temp;
		ifstream myFile(filename, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			//cout << temp.user_name;
			//cout << endl << temp.Pass;
			if (strcmp(temp.user_name, temp_username) == 0 && strcmp(temp.Pass, temp_password) == 0)
			{
				check = true;
				myFile.close();
				break;
			}

		}
		myFile.close();
		if (check == false)
		{
			cout << "Respective User Doesnot Exist" << endl;
		}
		return check;
	}
	void readCustomer(Customer& c)
	{ // will later on add store name and location
		Customer temp;
		ifstream myFile(filename, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			//cout << strcmp(temp.CNIC, m.CNIC) << endl;
			if (strcmp(temp.CNIC, c.CNIC) == 0)
			{
				cout << "UserName: " << temp.user_name << endl
					<< "CNIC: " << temp.CNIC << endl
					<< "Gender: " << temp.gender << endl
					<< "Phone_Number: " << temp.phone_number << endl
					<< "Personal_City: " << temp.personal_City << endl;
					//<< "Store name: " << temp.store_name << endl
					//<< "Store Location: " << temp.City << endl;

			}

		}
		myFile.close();
	}
	Customer& getCustomer(const char* temp_username, const char* temp_password)
	{
		Customer retCustomer;
		Customer temp;
		ifstream myFile(filename, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			if (strcmp(temp.user_name, temp_username) == 0 && strcmp(temp.Pass, temp_password) == 0)
			{

				retCustomer = temp;
				myFile.close();
			}
		}
		//readManager(retManager);
		return retCustomer;
	}
	//delete later on
	void DisplayCustomers()
	{
		Customer temp;
		ifstream myFile(filename, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{

			readCustomer(temp);
		}
		myFile.close();
	}
	bool readAllusername(const char* temp_username)
	{
		bool check = false;
		Customer temp;
		ifstream myFile(filename, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp))) {
			if (strcmp(temp.user_name, temp_username) == 0)
			{
				cout << "Username is being repeated" << endl;
				check = true;
				break;
			}
			else
				check = false;
		}
		myFile.close();
		return check;
	}
protected:
	void Customer_insert(Customer c)
	{
		ofstream myFile(filename, ios::binary|ios::app);
		if (myFile.write((char*)&c, sizeof(c)));
		cout << "Customer Successfully created!" << endl;
		myFile.close();
	}

	bool readAllCNIC(const char* temp_CNIC)
	{
		bool check = false;
		Customer temp;
		ifstream myFile(filename, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp))) {
			if (strcmp(temp.CNIC,temp_CNIC)==0)
			{
				cout << "CNIC is being repeated" << endl;
				check = true;
				break;
			}
			else
				check = false;
		}
		myFile.close();
		return check;
	}
//	void NoNeed(){}
};