#pragma once
#include<iostream>
#include <string.h>
#include <fstream>
using namespace std;
class Feedback
{
	int number;
	static int Number_assign;
	char statement[10000];
public:
	Feedback(){}
	void Enter_FeedBack()
	{
		string temp_statement;
		number = Number_assign++;
		cout << "Enter Youe Feedback" << endl;
		cin>>temp_statement;
		strcpy_s(statement, 10000, temp_statement.c_str());
		insert_Feedback(*this);
	}
	void Display()
	{
		cout << "( " << number << " )_" << statement << endl;
	}
	void insert_Feedback(Feedback object)
	{
		ofstream myFile("FeedBack.bin", ios::binary | ios::app);
		if (myFile.write((char*)&object, sizeof(object)))
		{
			cout << "Object inserted" << endl;//remove later on 
		}

		myFile.close();
	}
	void Display_FeedBacks()//displays the whole file 
	{
		Feedback temp;
		ifstream myFile("FeedBack.bin", ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			temp.Display();
			//cout << endl;
		}
		myFile.close();
	}
	void deleteObject(int serial)
	{
		Feedback temp;
		fstream myFile("FeedBack.bin", ios::in | ios::out | ios::binary);
		ofstream myFile_temp("temp_Product.bin", ios::app | ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			if (temp.number != serial)
			{
				myFile_temp.write((char*)&temp, sizeof(temp));

			}
		}
		myFile.close();
		myFile_temp.close();
		remove("FeedBack.bin");
		rename("temp_Product.bin", "FeedBack.bin");
	}
	bool SearchNumber(int serial)
	{
		bool check = false;
		Feedback temp;
		ifstream myFile("FeedBack.bin", ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			if (temp.number == serial)
			{
				check = true;
				myFile.close();
			}

		}
		myFile.close();
		if (check == false)
		{
			cout << "Feedback Doesnot Exist" << endl;
		}
		return check;
	}
};
int Feedback::Number_assign;