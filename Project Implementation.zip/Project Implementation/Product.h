#pragma once
#include<iostream>
#include <fstream>
#include <string.h>
using namespace std;
class Product
{
	char category[100];
	static int setserial_no;
	int serial_no;
	char item_name[100];
	double price;
	char units[50];
	int quantity;
	char status[50];
public:


	Product(string category="",string item_name = "", double price = 0, string units = "", int quantity = 0, string status = "Available")
	{
		strcpy_s(this->category,100, category.c_str());
		strcpy_s(this->item_name,100, item_name.c_str());
		this->price = price;
		strcpy_s(this->units, 50, units.c_str());
		this->quantity = quantity;
        strcpy_s(this->status, 50,status.c_str());
		set_status();
		//serial_no = setserial_no++;
		serial_no = -1;
	}
	void set_Entities(string category = "", string item_name = "", double price = 0, string units = "", int quantity = 0, string status = "Available")
	{
		strcpy_s(this->category, 100,category.c_str());
		strcpy_s(this->item_name, 100,item_name.c_str());
		this->price = price;
		strcpy_s(this->units,50, units.c_str());
		this->quantity = quantity;
		strcpy_s(this->status,50, status.c_str());
		this->serial_no = setserial_no++;
		set_status();
	}
	void Create_Product()
	{
		cout << "Enter the Category: ";
		cin >> this->category;
		cout << "Enter Item name: ";
		cin >> this->item_name;
		cout << "Enter Price per Quantity: ";
		cin >> this->price;
		cout << "Enter Units: ";
		cin >> this->units;
		cout << "Enter Quantity: ";
		cin >> this->quantity;
		this->serial_no = setserial_no++;
		set_status();
	}
	double getPrice() { return price; }
	char* getCategory() { return category; }
	 int get_serial_number()
	{
		return serial_no;
	}
	void set_price(double p)
	{
		price = p;
	}
	void set_quantity(int q)
	{
		quantity = q;
		set_status();
	}
    void set_status()
	{
		if (quantity == 0)
		{
			strcpy_s(status, "Unavailable");
			//return true;
		}
		//return false;
	}
	int& get_quantity()
	{
		return quantity;
	}
	Product operator=(Product& temp)
	{
		strcpy_s(this->category, 100, temp.category);
		strcpy_s(this->item_name, temp.item_name);
		strcpy_s(this->units, temp.units);
		strcpy_s(this->status, temp.status);
		price = temp.price;
		quantity = temp.quantity;
		serial_no = temp.serial_no;
		return temp;
	}
	bool operator==(Product& temp)
	{
		bool check = false;
		if (strcmp(this->item_name, temp.item_name)==0 && strcmp(this->units, temp.units)==0 && (strcmp(this->category, temp.category))==0)
		{
			check = true;
		}
		return check;
	}
	void Display()
	{
		cout<<"Category: "<<category<<endl 
			<< "Product Name: " << item_name << endl
			<< "Serial Number: " << serial_no << endl
			<< "Price: Rs." << price << endl
			<< "Units: " << units << endl
			<< "Quantity Present: " << quantity << endl
			<< "Status: " << status << endl;
	}
};
// ********************************** read and write of Product are global***************************************//
	void insert_Product(const char* filename,Product object)
	{
		ofstream myFile(filename, ios::binary|ios::app);
		if (myFile.write((char*)&object, sizeof(object)))
		{
			cout << "Object inserted" << endl;//remove later on 
		}
		
		myFile.close();
	}
	void Display_Products(const char* filename)//displays the whole file 
	{
		Product temp;
		ifstream myFile(filename, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			temp.Display();
			cout << endl;
			cout << "-----------------------------------------" << endl;
		}
		myFile.close();
	}
	Product& getObject(const char* filename, int serial)
	{
		Product retProduct;
		Product temp;
		ifstream myFile(filename, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			if (temp.get_serial_number() == serial)
			{
			//	temp.Display();
				retProduct = temp;
				myFile.close();
			}
		}
	//	retProduct.Display();
		return retProduct;
	}
	void Update(const char* filename,Product object)
	{
		Product temp;
		fstream myFile(filename, ios::in | ios::out | ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			if (temp.get_serial_number() == object.get_serial_number())
			{
				temp = object;
				int current = myFile.tellg();
				int oneblock = sizeof(temp);
				myFile.seekg(current - oneblock);
				myFile.write((char*)&temp, sizeof(temp));
				myFile.close();
			}
		}
     }
	void deleteObject(const char* filename,int serial)
	{
		Product temp;
		fstream myFile(filename, ios::in | ios::out | ios::binary);
		ofstream myFile_temp("temp_Product.bin", ios::app | ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			if (temp.get_serial_number() != serial)
			{
				myFile_temp.write((char*)&temp, sizeof(temp));

			}
		}
		myFile.close();
		myFile_temp.close();
		remove(filename);
		rename("temp_Product.bin", filename);
	}
	bool SearchSerial(const char* filename, int serial)
	{
		bool check = false;
		Product temp;
		ifstream myFile(filename, ios::binary);
			while (myFile.read((char*)&temp, sizeof(temp)))
			{
				if (temp.get_serial_number() == serial)
				{
					check = true;
					myFile.close();
				}
				
			}
			myFile.close();
			if (check == false)
			{
				//cout << "Serial Number Doesnot Exist" << endl;
			}
			return check;
	}
	

int Product::setserial_no;