#pragma once
#include <iostream>
#include <string.h>
#include<fstream>
//#include "../ThirdSemesterProjectOOP/VectorC.h"
#include "../ThirdSemesterProjectOOP/Person.h"
#include "../ThirdSemesterProjectOOP/Customer.h"
#include "Manager.h"
#include "Catalogue.h"
#include "Store.h"
#include "Feedback.h"
using namespace std;
const char* fileName = "Admin.bin";
class Admin :public Person
{
public:
	Admin(int i) :Person() {}
	Admin() :Person("234234", "AdMIn@1997", "Admin", "23423423", "093249483", "324234") {
		//Admin_insert(*this);
	}
	void EnterAdmin()
	{
		//	system("CLS");
		do {
			cout << "Enter CNIC";
			cin >> CNIC;
		} while (!Verify_CNIC(CNIC));
		cout << "Enter Gender";
		cin >> gender;
		cout << "Enter Phone Number";
		cin >> phone_number;
		cout << "Enter Personal City";
		cin >> personal_City;
		cout << "Admin Created";
		//cout << this->gender << this->phone_number << this->personal_City;
		// do file handling after this, make a file admin that writes admin info in the file
		Admin_insert(*this);
		return;
	}
	void LogIN()
	{
		//int opt_1;
		char temp_username[100], temp_Pass[100];
		//char tempuser[100], pass[100];
		do {
			cout << "Enter username";
			cin >> temp_username;
			do
			{
				cout << "Enter Password";
				cin >> temp_Pass;
			} while (!Verify_Password(temp_Pass));
		} while (!Verify(temp_username, temp_Pass));
		//cout << "----------------";
		readAdmin();

	}
	//Manager&
	void DeleteCustomer()
	{
		Customer temp;
		temp.DisplayCustomers();
		//temp.readCustomer()
		char temp_user_name[100];
		do
		{
			cout << "Enter The User Name Of the Customer You Want To Delete";
		cin >> temp_user_name;
		} while (!temp.readAllusername(temp_user_name));
		cout << "If username repeated,means it was already present" << endl;
		temp.DeleteCustomers(temp_user_name);
		//temp.DisplayCustomers();
	}
	void ManageFeedBacks(Feedback& f)
	{
		int temp_n;
		char con;
		f.Display_FeedBacks();
		do
		{
			do
			{
				cout << "Enter the Number of Feedback you will like to delete" << endl;
				cin >> temp_n;
			} while (!(f.SearchNumber(temp_n)));
			if (f.SearchNumber(temp_n))
			{
				f.deleteObject(temp_n);
				f.Display_FeedBacks();
			}
			cout << "If want to Continue press Y/y" << endl;
			cin >> con;
		} while (con == 'Y' || con == 'y');
	}
	void CreateManager(Manager& m)
	{
		char temp_pass[100], temp_username[100], temp_storename[100], temp_storeCity[100];
		do {
			cout << "Enter Password for the Manager: ";
			cin >> temp_pass;
		} while (!Verify_Password(temp_pass));
		//	cout << "Enter Store name";
			//cin >> temp_storename;

		//	m.setPass(temp_pass);
		do {
			cout << "Enter Store City";
			cin >> temp_storeCity;
		} while (m.checkCity(temp_storeCity));
		do
		{
			cout << "Enter User_Name for the Manager: ";
			cin >> temp_username;
		} while (!(m.setUserName(temp_username, temp_pass, temp_storeCity)));
		//m.setPass(temp_pass);
	//	return m;
		//return true;
		//still has to appoint store to a manager
		//number of manager is equal to the number of manager
	}
	void ManageCatalogue(Catalogue& c)
	{
		int opt_1;
		char con;
		if (c.checkifcatalogue())
		{
			cout << "Catalogue Exists";
		}
		else
			c.CreateCatalogue();
		do {


			cout << "Delete Product in Catalogue: Press 1" << endl
				<< "Add Into Catalogue: Press 2" << endl
				<< "Update a Product in Catalogue: Press 3" << endl
				<< "Want to display Catalogue:Press 4" << endl;
			cin >> opt_1;
			switch (opt_1)
			{
			case 1:
				c.DeleteProductinCatalogue();
				break;
			case 2:
				c.Add_Product();
				break;
			case 3:
				c.EditProduct();
				break;
			case 4:
				c.DisplayCatalogue();
				break;
			}
			cout << "If you want to continue Press Y\y" << endl;
			cin >> con;
		} while (con == 'Y' || con == 'y');
	}
	char* CreateStore(Store& s)
	{
		char con;
		bool check;
		char Cities[100] = "\0";
		string sname;
		do {
			//file created on the basis of city, if city repeated,it wont create new file because file already created??
			cout << "Enter store City: ";
			cin >> sname;
			check = s.setCity(sname);
			if (check)
			{
				strcpy_s(Cities, 100, sname.c_str());
			}
			cout << "If want to continue,Press Y\y" << endl;
			cin >> con;
		} while (con == 'y' || con == 'Y');
		return Cities;
	}
protected:
	void Admin_insert(Admin object)
	{
		ofstream myFile(fileName, ios::binary | ios::app);
		if (myFile.write((char*)&object, sizeof(object)));
		cout << "Admin Successfully created!" << endl;
		myFile.close();
	}
	bool Verify(const char* temp_username, const char* temp_password)
	{
		bool check = false;
		Admin temp(1);
		/*i*/ifstream myFile(fileName, ios::binary);//| ios::in );
		//	cout << sizeof(temp);

		while (myFile.read((char*)&temp, sizeof(temp)))
		{

			//cout << temp.getCNIC();
			//cout << temp.user_name;
			//cout << temp.Pass;
			if (strcmp(temp.user_name, temp_username) == 0 && strcmp(temp.Pass, temp_password) == 0)
			{

				//cout << "login";
				check = true;
				myFile.close();
				break;
			}
		}

		//return false;
		myFile.close();
		return check;
	}
	void readAdmin()
	{
		Admin temp(1);
		ifstream myFile(fileName, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			cout << "UserName: " << user_name << endl
				<< "CNIC: " << CNIC << endl
				<< "Gender: " << gender << endl
				<< "Phone_Number: " << phone_number << endl
				<< "Personal_City: " << personal_City << endl;
			myFile.close();
		}
	}
//	void NoNeed(){};
};