#pragma once
#include <iostream>
using namespace std;
class CheckOut
{
public:
	int COD(bool check)
	{
		if (check)//when in same City
		{
			return 30;
		}
		else
		{
			return 50;
		}
	}
	void CreditCard()
	{
		string Code;
		cout << "Enter Code for Credit Card";
		cin >> Code;
	}
	void EasyPaisa()
	{
		string phonenumber;
		cout << "Enter the phone number you will preffer" << endl;
		cin >> phonenumber;
	}
};