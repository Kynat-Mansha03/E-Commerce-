#pragma once

#include <string.h>
#include <cstring>
#include <fstream>
//#include "../ThirdSemesterProjectOOP/VectorC.h"
#include "../ThirdSemesterProjectOOP/Person.h"
#include <iostream>
using namespace std;
const char* file = "Manager.bin";
class Manager:public Person
{
//	char store_name[100];//admin gives this
	char City[100];//of store admin gives this
public:
	//Manager(int i ){}
	Manager()
	{
		//Manager_insert(*this);
	}
void EnterManager()
{
	
		system("CLS");
		do {
			do {
				cout << "Enter CNIC: ";
				cin >> this->CNIC;
			} while (!Verify_CNIC(CNIC));
		} while (readAllCNIC(CNIC));
		cout << "Enter Gender: ";
		cin >> this->gender;
		cout << "Enter Phone_Number: ";
		cin >> this->phone_number;
		cout << "Personal_City: ";
		cin >>this-> personal_City;
		Manager_insert(*this);
		//readManager(*this);
	}
	//void setPass(string temp_Pass)//const char* temp_Pass)
	//{
	//	strcpy_s(Pass,100,temp_Pass.c_str());
	//	//cout << Pass;
	//	Update_Manager();
	//}
        
	bool setUserName(string username,string temp_Pass,string temp_storeCity)//const char* username)
	{
		bool check_2=readAllusername(username.c_str());
		if (check_2)
		{
			cout << "UserName is being repeated";
			return false;
		}
		else

		{
			strcpy_s(user_name, 100, username.c_str());
			strcpy_s(Pass, 100, temp_Pass.c_str());
			//strcpy_s(store_name, 100, temp_storename.c_str());
			strcpy_s(City, 100, temp_storeCity.c_str());
		}
	//	cout << user_name;
		Update_Manager();
		return true;
	}
	bool Verify(const char* temp_username, const char* temp_password)
	{
		bool check = false;
		Manager temp;
		ifstream myFile(file, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			//cout << temp.user_name;
			//cout << endl << temp.Pass;
			if (strcmp(temp.user_name , temp_username)==0 && strcmp(temp.Pass , temp_password)==0)
			{
				check = true;
				myFile.close();
				break;
			}
			
		}
		myFile.close();
		if (check == false)
		{
			cout << "Respective User Doesnot Exist" << endl;
		}
		return check;
	}
	void readManager(Manager &m)
	{ // will later on add store name and location
		Manager temp;
		ifstream myFile(file, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			//cout << strcmp(temp.CNIC, m.CNIC) << endl;
			if (strcmp(temp.CNIC ,m.CNIC)==0)
			{
				cout << "UserName: " << temp.user_name << endl
					<< "CNIC: " << temp.CNIC << endl
					<< "Gender: " << temp.gender << endl
					<< "Phone_Number: " << temp.phone_number << endl
					<< "Personal_City: " << temp.personal_City << endl
					//<< "Store name: " << temp.store_name << endl
					<< "Store Location: " << temp.City << endl;

			}
			
		}
		myFile.close();
	}
	bool checkCity(string city)
	{
		bool check = false;
		Manager temp;
		ifstream myFile(file, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			if (temp.City == city)
			{
				check = true;
				myFile.close();
				break;
			}
		}
		myFile.close();
		return check;
	}
	Manager& getManager(const char* temp_username, const char* temp_password)
	{
		Manager retManager;
		Manager temp;
		ifstream myFile(file, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			if (strcmp(temp.user_name, temp_username) == 0 && strcmp(temp.Pass, temp_password) == 0)
			{

				retManager = temp;
				myFile.close();
			}
		}
		//readManager(retManager);
		return retManager;
	}
	Manager& getManager(string city)
	{
		Manager retManager;
		Manager temp;
		ifstream myFile(file, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			if (temp.City== city)
			{
				
				retManager = temp;
				myFile.close();
			}
		}
		readManager(retManager);
		return retManager;
	}
	const char* getCity() /*const*/ { return City; }
protected:
	void Manager_insert(Manager object)
	{
		ofstream myFile(file, ios::binary|ios::app);
		if (myFile.write((char*)&object, sizeof(object)));
		//cout << "Manager Successfully created!" << endl;
		myFile.close();
	}
	void Update_Manager()
	{
		Manager temp;
		fstream myFile(file, ios::in | ios::out | ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp))) {
			//readManager(temp);
			if (strcmp(temp.CNIC,CNIC)==0) {
				//errno_t strcpy_s(temp.CNIC,CNIC.length(), CNIC.c_str());//why not working 
				//will this work 
			   //temp.CNIC = CNIC;
				//cout << "Getting updated" << endl;
				strcpy_s(temp.user_name, user_name);
				strcpy_s(temp.Pass, Pass);
				//strcpy_s(temp.store_name,store_name);
				strcpy_s(temp.City,City);
				int current = myFile.tellg();
				int oneblock = sizeof(temp);
				myFile.seekg(current - oneblock);
				myFile.write((char*)&temp, sizeof(temp));
				myFile.close();
			}
		}
		//readManager(*this);
	}
	bool readAllusername(const char* temp_username)
	{
		bool check = false;
		Manager temp;
		ifstream myFile(file, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp))) {
			if (strcmp(temp.user_name , temp_username)==0)
			{
				check = true;
				break;
			}
			else
				check = false;
		}
		myFile.close();
		return check;
	}
	bool readAllCNIC(const char* temp_CNIC)
	{
		bool check = false;
		Manager temp;
		ifstream myFile(file, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp))) {
			if (strcmp(temp.CNIC,temp_CNIC)==0)
			{
				cout << "CNIC is being repeated" << endl;
				check = true;
				break;
			}
			else
				check = false;
		}
		myFile.close();
		return check;
	}
//	void NoNeed() {};
};