#pragma once

#include <string.h>
#include "../ThirdSemesterProjectOOP/Customer.h"
#include "../ThirdSemesterProjectOOP/Manager.h"
//#include "../ThirdSemesterProjectOOP/VectorC.h"
#include "Feedback.h"
#include "Admin.h"
#include "Catalogue.h"
#include "Store.h"
#include <iostream>
using namespace std;
class Registration
{
	Admin A; // have only one admin 
	//VectorC<Manager*>list_of_Managers;
	//Manager* list_of_Managers = new Manager[50];
	Manager* temp_m;
	//VectorC<Customer*>list_of_Customers;
	//Customer* list_of_Customer = new Customer[1000];
	Customer* temp_c;
	Store* s;//no of stores is equal to number of ma
	Catalogue c;
	char** Cities;
	int nu_admin = 0;
	int nu_Manager = 0;
	int nu_Customer = 0;
	int nu_Cities = 0;
	//int nu_store = 0;
public:
	Registration()
	{

	}
	void start()
	{
		Cities = new char* [100];
		for (int i = 0; i < 100; i++)
		{
			Cities[i] = new char[100];
		}
		for (int i = 0; i < 100; i++)
		{
			strcpy_s(Cities[i],100,"\0");
		}
		if (readManagerFile())
		{
			getCity();
		}
		//while()
		bool check;
		//system("CLS");
		int opt_1, opt_2, opt_3;
		char opt_4;
		cout << "Username of Admin: " << A.getName() << endl;
		cout << "Password for Admin: " << A.getPass() << endl;
		nu_admin++;
		check = readManagerFile();
		if (check)
		{
			nu_Manager++;
		}
		check = readCustomerFile();
		if (check)
		{
			nu_Customer++;
		}
		//A.EnterAdmin();
		//system("CLS");
		do {
			if (nu_admin > 0 || nu_Manager > 0 || nu_Customer > 0)
			{

				cout << "Enter 1 if want to login in";
			}
			//for(int )
			cout << "Enter 2 if want to sign up";
			cin >> opt_1;
			system("CLS");
			switch (opt_1)
			{
			case 1:
				if (nu_admin > 0)
					cout << "Press 1 if want to log in as Admin" << endl;
				if (nu_Manager > 0)
					cout << "Press 2 if want to log in as Manager" << endl;
				if (nu_Customer > 0)
					cout << "Press 3 if want to log in as Customer" << endl;
				cin >> opt_2;
				switch (opt_2)
				{
				case 1:
					A.LogIN();
					cout << "(1)_ Want to Create a Manager" << endl
						<< "(2)_ Want to Remove a Customer" << endl
						<< "(3)_ Want to Manage Catalogue" << endl
						<< "(4)_Create Store" << endl
						<< "(5)_Manage Feedbacks" << endl;
					cin >> opt_3;
					switch (opt_3)
					{
					case 1:


					{
						temp_m = new Manager;
						temp_m->EnterManager();
						//list_of_Managers[nu_Manager] = 
					    A.CreateManager(*temp_m);
						nu_Manager++;
					}
					break;
					case 2:
						//will delete the customer after taking the CNIC/ username of the specific customer
						A.DeleteCustomer();
						break;

					case 3:
						A.ManageCatalogue(c);
						break;
					case 4:
						s = new Store;
						strcpy_s(Cities[nu_Cities],100,A.CreateStore(*s));
						cout << Cities[nu_Cities] << endl;
							nu_Cities++;
						break;
					case 5:
					{
						Feedback temp_f;
						A.ManageFeedBacks(temp_f);
					}
					}
					break;
				case 2:
					loginManager();
					//operate shop options in the end
					break;
				case 3:
					loginCustomer();
					break;
				}
				break;
			case 2://sign up is only for customer because admin only one already signed up and admin signs up the manager

			{
				temp_c = new Customer;
				//list_of_Customer[nu_Customer].EnterCustomer();
				temp_c->EnterCustomer();
				//list_of_Customers.Push(customer);
			}
			nu_Customer++;
			break;

			}
			system("cls");
			cout << "If you want to continue press Y or y";
			cin >> opt_4;
		} while (opt_4 == 'Y' || opt_4 == 'y');
	}
protected:
	void loginManager()
	{
		char temp_City[100];
		Inventory temp;
		char con;
		Manager m;
		int opt_1;
		string temp_username;
		string temp_pass;
		system("CLS");
		int i = 0;
		do {
			do
			{
				cout << "Enter Username";
				cin >> temp_username;
				cout << " Enter Password";
				cin >> temp_pass;

			} while (!m.Verify(temp_username.c_str(), temp_pass.c_str()));
			cout << "If you want to continue press Y\y";
			cin >> con;
		} while (con == 'Y' || con == 'y');


		if (m.Verify(temp_username.c_str(), temp_pass.c_str()))
		{
			m = m.getManager(temp_username.c_str(), temp_pass.c_str());
			m.readManager(m);
			if (c.checkifcatalogue())
			{
				s = new Store;
				do {
					cout << "(1)_If you want to Manage your store " << endl
						<< "(2)_If you want to view Inventory of another store";
					cin >> opt_1;
					switch (opt_1)
					{
					case 1:
						s->AllowManager(m);
						break;
					case 2:
						cout << "Enter the name of the City you want to view Inventory of" << endl;
						cin >> temp_City;
						temp.ViewInventory(temp_City);
						break;
					}
					cout << "If you want to continue press Y\y";
					cin >> con;
					system("CLS");
				} while (con == 'Y' || con == 'y');
			}
			else
			{
				cout << "Catalogue doesnot exist." << endl
					<< "Consult the Admin" << endl;
			}
		}


		//later on implement store options

	}
	void loginCustomer()
	{
		char con;
		Customer c;
		string temp_username;
		string temp_pass;
		system("CLS");
		int i = 0;

		do {
			do
			{
				cout << "Enter Username";
				cin >> temp_username;
				cout << " Enter Password";
				cin >> temp_pass;

			} while (!c.Verify(temp_username.c_str(), temp_pass.c_str()));
			cout << "If you want to continue press Y\y";
			cin >> con;
		} while (con == 'Y' || con == 'y');

		//list_of_Customer[i].readCustomer();
		//operate cart in the end
		if (c.Verify(temp_username.c_str(), temp_pass.c_str()))
		{
			c = c.getCustomer(temp_username.c_str(), temp_pass.c_str());
			c.readCustomer(c);
		}
		c.CreateCart(Cities);
		//return;
	}

   bool readManagerFile()
   {
	 // will later on add store name and location
		bool check = false;
		Manager temp;
		ifstream myFile(file, ios::binary);
		if (myFile.read((char*)&temp, sizeof(temp)))
		{
			check = true;
		}
		myFile.close();
		return check;
	}
bool readCustomerFile()
{
	 // will later on add store name and location
		bool check = false;
		Customer temp;
		ifstream myFile(filename, ios::binary);
		if (myFile.read((char*)&temp, sizeof(temp)))
		{
			check = true;
		}
		myFile.close();
		return check;
	}
    void getCity()
	{
		Manager temp;
		ifstream myFile(file, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			strcpy_s(Cities[nu_Cities],100,temp.getCity());
			cout << Cities[nu_Cities] << endl;
			nu_Cities++;
		}
		myFile.close();
	}
};