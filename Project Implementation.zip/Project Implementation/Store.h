#pragma once
//admin creates a store and assigns manager to it based on the city match
#include <iostream>
#include <string.h>
#include "Catalogue.h"
#include "Inventory.h"
#include "Manager.h"
char* storefilename = new char[100];
class Store
{
	
	Inventory I;
	char City[100];//creates file on the name of city
public:
	Store(){}
	void storeInsert( const char* filename, Store Object)
	{
		//filename = filename + ".bin";
		ofstream myFile(filename, ios::binary | ios::app);
		if (myFile.write((char*)&Object, sizeof(Object)))
		{
			cout << "Object inserted";//how do i insert inventory or do i just match the city of inventory
		}
		else
			cout << "Object not inserted";
		myFile.close();
	}
	bool setCity(string City)
	{
		bool check;
		strcpy_s(storefilename, 100, City.c_str());
		strcat_s(storefilename, 100, ".bin");
		if (checkCity(storefilename,City))
		{
			cout << "Store City is being repeated" << endl;
			check = false;
		}
		else
		{
			strcpy_s(this->City, 100, City.c_str());
			storeInsert(storefilename, *this);
			check = true;
		}
		return check;
	}
	void AllowManager(Manager& m)//admin does this by matching the store address wiht the store City the Manager was appointed
	{
		char con1;
		system("cls");
		int opt_1;
		//Manager temp_m;
		//Manager edits,update and add in inventory based on the catalogue
		
			strcpy_s(storefilename, 100,m.getCity());
			strcat_s(storefilename, 100, ".bin");
			if (checkCity(storefilename, m.getCity()))
			{
				strcpy_s(this->City, 100, m.getCity());
				cout << "Store Has A Manager";
				m = m.getManager(City);//for checking to see if the manager is same 
				m.readManager(m);
				I.setInventoryName(City);
				do {
					cout << "(1)_Want to Insert In Inventory" << endl
						<< "(2)_Want to Update Product in Inventory" << endl
						<< "(3)_Want to Add into the Inventory" << endl
						<< "(4)_Want to Delete Prodcut from the Inventory" << endl;
					cin >> opt_1;
					switch (opt_1)
					{
					case 1:
						I.InsertInInventory();
						break;
					case 2:
						I.UpdateProductOfInventory();
						break;
					case 3:
						I.AddINInventory();
						break;
					case 4:
						I.Delete();
						break;

					}

					system("cls");
					cout << "Want to continue,Press Y/y" << endl;
					cin >> con1;
				} while (con1 == 'Y' || con1 == 'y');
			}
			else
			{
				cout << "Respective Store has NO Manager" << endl
					<< "Request the Admin to Create one" << endl
					<< "Or No such store exists.Please,consult the Admin" << endl;
			}
		return;
	}
	bool checkCity(const char* filename,string City)
	{
		bool check = false;
		Store temp;
		ifstream myFile(filename, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			if (temp.City == City)
			{
				check = true;
				myFile.close();
				break;
			}
		}
		myFile.close();
		return check;
	}
	Store& getStore(const char* City)
	{
		Store retStore;
		Store temp;
		ifstream myFile(storefilename, ios::binary);
		while (myFile.read((char*)&temp, sizeof(temp)))
		{
			if (strcmp(temp.City,City) == 0)
			{

				retStore = temp;
				myFile.close();
			}
		}
		//readManager(retManager);
		return retStore;
	}
	void ViewInventoryOfStore()
	{
		I.ViewInventory(this->City);
	}
	char* getCity() { return City; }
};